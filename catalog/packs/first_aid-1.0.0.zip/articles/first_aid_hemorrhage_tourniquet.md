# Massive Hemorrhage Control & Tourniquet Application

Arterial hemorrhage can cause fatal exsanguination in under 3 minutes. Stop the bleeding before any other intervention.

## 1. Stepwise Bleeding Control Hierarchy
1. **Immediate Firm Direct Pressure:** Press directly onto the bleeding site using sterile gauze, clean cloth, or gloved hands. Lean your full body weight into the wound.
2. **Wound Packing (Junctional Areas - Groin, Axilla, Neck):**
   - Pack hemostatic gauze (quikclot/kaolin) or standard gauze tightly into the wound cavity directly against the bleeding vessel.
   - Maintain continuous direct pressure over the packed wound for at least 3 minutes (5 minutes for non-hemostatic gauze).
3. **Tourniquet (Extremity Wounds):** Apply immediately for life-threatening limb hemorrhage.

## 2. Tourniquet Application Procedure (Combat Application Tourniquet - CAT)
1. Place the tourniquet **2 to 3 inches above the bleeding site**, directly on the skin (never over a joint; if bleeding location is unclear in the dark, place "high and tight" on the limb).
2. Pull the self-adhering band tightly to eliminate all slack before turning the windlass.
3. Twist the windlass rod until the arterial bleeding stops completely and distal pulse vanishes.
4. Lock the windlass rod into the clip.
5. Secure the friction buckle strap and write the exact time of application on the time tag (e.g., "TK 14:35").

## 3. Critical Tourniquet Safety Rules
- **Never loosen or remove a tourniquet in the field.** Removal must only be performed by medical personnel in a surgical setting.
- An improperly applied loose tourniquet acts as a venous tourniquet, increasing bleeding rather than stopping it.
- Pain is expected and indicates effective arterial occlusion.