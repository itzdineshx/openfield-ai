# Burn Classification & Emergency Treatment

Immediate cooling and sterile dressing minimize tissue damage and infection risk following thermal, chemical, or electrical burns.

## 1. Burn Depth Classification
- **First-Degree (Superficial):** Affects only the epidermis. Red, painful, dry, no blisters (e.g., mild sunburn).
- **Second-Degree (Partial-Thickness):** Involves epidermis and dermis. Redness, severe pain, edema, and fluid-filled blisters.
- **Third-Degree (Full-Thickness):** Extends through all skin layers into subcutaneous tissue. Leathery, charred black or waxy white, often painless at the center due to nerve destruction.

## 2. Emergency Management Steps
1. **Extinguish & Remove Source:** Smother flames, disconnect electrical supply, or brush dry chemicals off before flushing.
2. **Cool with Clean Running Water:** Apply cool running tap water (15°C - 20°C) over the burn for **at least 20 minutes**. Do this within the first 3 hours of injury.
   - *Warning:* Never use ice or ice-cold water; extreme cold constricts capillary blood flow, deepening tissue necrosis.
3. **Remove Constricting Items:** Gently take off rings, watches, belts, and tight clothing before swelling develops. Do not peel off clothing stuck to the wound.
4. **Cover the Burn:** Cover loosely with a sterile, non-adherent dressing, clean polyethylene plastic food wrap (applied lengthways, not wrapped tightly), or clean damp cloth.
5. **Keep Casualty Warm:** Extensive burns impair thermoregulation; wrap unburned areas in blankets to prevent hypothermia.

## 3. Do NOT Practices
- Do not apply butter, oil, grease, toothpaste, or home ointments.
- Do not burst intact blisters; the blister roof acts as a biological sterile barrier.