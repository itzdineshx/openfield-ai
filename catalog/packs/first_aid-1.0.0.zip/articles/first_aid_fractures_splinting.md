# Fractures, Dislocations & Field Splinting

Immobilizing suspected bone fractures and joint dislocations prevents further soft tissue trauma, reduces pain, and prevents closed fractures from puncturing through the skin.

## 1. Signs of a Fracture
- Severe localized pain and tenderness.
- Visible deformity, unnatural angulation, or limb shortening.
- Swelling, bruising (ecchymosis), and inability to bear weight.
- Crepitus (grating sensation of bone ends touching).

## 2. Neurovascular Examination (PMS Protocol)
Always assess and record **PMS** distal to the injury **before and after** applying any splint:
1. **P - Pulse:** Check distal arterial pulse (radial pulse for arm, dorsalis pedis for leg).
2. **M - Motor:** Ask casualty to gently wiggle fingers or toes.
3. **S - Sensory:** Touch extremities and ask casualty if they feel it without looking.
- If distal pulse is absent, emergency reduction or repositioning may be required by trained medics.

## 3. Splinting Rules
- **Immobilize the Joint Above and Below:** For a mid-shaft forearm fracture, immobilize both the wrist and the elbow. For an ankle fracture, immobilize the foot and the knee.
- **Pad the Splint:** Pad rigid items (sticks, rolled magazines, padded boards, SAM splints) with cloth to eliminate pressure sores over bony prominences.
- **Secure in Position Found:** Never attempt to forcefully straighten a dislocated joint or push exposed bone back into an open fracture.
- **Open Fractures:** Cover exposed bone ends with sterile moist gauze before splinting.