# Cardiopulmonary Resuscitation (CPR) & Airway Obstruction

When a casualty is unresponsive and not breathing normally (or only gasping), immediate high-quality CPR maintains oxygenated blood flow to the brain and vital organs until definitive care arrives.

## 1. Initial Assessment Protocol (DRSABCD)
1. **D - Danger:** Ensure the scene is safe for yourself, bystanders, and the casualty.
2. **R - Response:** Check for consciousness. Tap shoulders firmly and ask loudly: "Can you hear me? Open your eyes!"
3. **S - Send for Help:** Call emergency services (112, 911, or local dispatch) or direct a bystander to call and locate an Automated External Defibrillator (AED).
4. **A - Airway:** Open the airway using the head-tilt/chin-lift maneuver. Check the mouth for visible foreign blockages.
5. **B - Breathing:** Look, listen, and feel for normal chest rise for no more than 10 seconds. Agonal gasps are not normal breathing.
6. **C - CPR:** Immediately begin chest compressions if unbreathing.
7. **D - Defibrillation:** Attach AED pads as soon as available and follow audio prompts.

## 2. High-Quality Chest Compressions
- **Positioning:** Place the heel of one hand in the center of the chest (lower half of sternum) and interlock the other hand on top. Keep arms straight and shoulders positioned directly over the hands.
- **Compression Depth:** Compress the chest at least 5 cm (2 inches), but no more than 6 cm in adults.
- **Compression Rate:** 100 to 120 compressions per minute (tempo of "Stayin' Alive").
- **Full Recoil:** Allow the chest to fully re-expand between compressions to facilitate cardiac refill; do not lean on the chest.
- **Ratio:** 30 chest compressions followed by 2 rescue breaths. If untrained or unwilling to deliver rescue breaths, deliver continuous hands-only CPR.

## 3. Foreign Body Airway Obstruction (Choking)
- **Mild Obstruction (Casualty can speak, cough loudly):** Encourage vigorous coughing. Do not interfere.
- **Severe Obstruction (Silent, clutching neck, cyanotic lips):**
  1. Stand to the side and slightly behind the casualty. Support chest with one hand and lean them forward.
  2. Deliver up to **5 sharp back blows** between the shoulder blades with the heel of your hand.
  3. If back blows fail, deliver up to **5 abdominal thrusts (Heimlich maneuver)**: Position a fist just above the navel, grasp with the other hand, and pull inward and upward sharply.
  4. Repeat sequence. If casualty becomes unresponsive, lower carefully to the ground and initiate CPR immediately.