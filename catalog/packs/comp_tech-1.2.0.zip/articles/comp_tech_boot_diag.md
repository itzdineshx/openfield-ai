# PC Boot Sequence & Hardware Fault Isolation

Understanding the standard boot sequence allows technicians to isolate hardware failures, firmware corruption, and operating system loader errors.

## 1. Boot Stages
1. **Power Supply On (PS-ON):** Power supply asserts Power Good (+5V on grey wire) once all DC voltage rails (+12V, +5V, +3.3V) stabilize within tolerance.
2. **Firmware POST (Power-On Self Test):** The motherboard UEFI/BIOS initializes the CPU, detects memory (RAM), scans PCIe buses, and initializes the GPU.
3. **Bootloader Hand-off:** UEFI locates the EFI System Partition (ESP formatted in FAT32) and executes the bootloader (e.g., Windows Boot Manager `bootmgfw.efi` or GRUB `grubx64.efi`).
4. **Kernel Initialization:** The OS kernel loads device drivers and starts initialization daemons (`systemd` in Linux, `smss.exe` in Windows).

## 2. POST Diagnostic Codes & Symptoms
- **No Fans, No LEDs:** Dead PSU, tripped overcurrent protection (short-to-ground on 12V CPU or GPU rail), or disconnected front panel header.
- **Fans Spin, No Display (Black Screen):**
  - Continuous long beeps or cycling debug LEDs: RAM initialization failure. Reseat memory modules in dual-channel slots (typically A2 and B2).
  - 1 long beep, 2 or 3 short beeps: GPU failure or PCIe power cable unseated.
  - POST debug display codes (e.g., `00` or `FF`: CPU unseated or dead BIOS; `55` or `53`: Memory not detected).
- **"No Bootable Device Found":**
  - SATA/NVMe drive disconnected or failed.
  - UEFI boot mode mismatch (CSM/Legacy vs UEFI native).
  - Corrupt partition table or EFI partition.

## 3. Storage Drive Health (SMART)
- Use `smartctl -a /dev/nvme0n1` or CrystalDiskInfo.
- Critical SMART attributes to monitor:
  - `05 Reallocated Sectors Count`: Non-zero indicates physical platter degradation.
  - `B8 End-to-End Error`: Data path hardware integrity issue.
  - `0A Spin Retry Count`: Mechanical spindle motor failure.