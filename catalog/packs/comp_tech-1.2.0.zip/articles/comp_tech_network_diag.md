# Network Diagnostics & Connectivity Troubleshooting

When diagnosing local area network (LAN) and wide area network (WAN) outages, apply a systematic bottom-up troubleshooting methodology based on the OSI model.

## Phase 1: Physical and Link Layer Verification
1. Check interface status: `ip link show` or `ifconfig`. Confirm the state is `UP` and carrier is detected.
2. Verify local IP assignment: `ip addr show`. Verify that an IPv4 address has been assigned by DHCP (e.g., `192.168.1.50/24`) and not an APIPA fallback address (`169.254.x.x`).

## Phase 2: Gateway and Local Subnet Routing
1. Check routing table: `ip route show`. Identify the default gateway (e.g., `default via 192.168.1.1 dev eth0`).
2. Ping local gateway: `ping -c 4 192.168.1.1`.
   - If ping fails: The issue is local to the device, Ethernet cable, or Wi-Fi router.
   - If ping succeeds: Local link is operational; proceed to public routing.

## Phase 3: External IP Reachability (WAN)
1. Ping a reliable public IP address directly to bypass DNS: `ping -c 4 8.8.8.8` or `1.1.1.1`.
   - If ping succeeds: Internet connectivity is alive; failures are due to DNS name resolution.
   - If ping fails with "Destination Host Unreachable": Default gateway cannot route upstream; check ISP modem or WAN interface.

## Phase 4: DNS Name Resolution
1. Test domain resolution: `dig google.com +short` or `nslookup google.com`.
2. Inspect resolver configuration in `/etc/resolv.conf`.
3. If DNS fails, test querying public resolvers directly: `dig @1.1.1.1 google.com`. If direct query succeeds, replace local DNS servers in network configuration.

## Phase 5: Port and Service Inspection
1. Inspect active listening ports: `ss -tulpn` (or `netstat -tulpn`).
2. Verify target remote port connectivity: `nc -zv target-host 443` or `curl -Iv https://target-host`.