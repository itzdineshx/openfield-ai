# Linux File Permissions & Ownership

In Linux and Unix-like operating systems, file permissions and ownership protect system integrity and user privacy. Every file and directory is governed by three permission scopes: User (owner), Group, and Others.

## 1. Permission Representation
When inspecting files via `ls -l`, permissions appear as a 10-character string (e.g., `-rwxr-xr--`):
- Char 1: File type (`-` regular file, `d` directory, `l` symbolic link).
- Chars 2-4: Owner permissions (Read `r`, Write `w`, Execute `x`).
- Chars 5-7: Group permissions.
- Chars 8-10: Others (world) permissions.

## 2. Octal Mode Representation
Permissions are commonly represented in octal notation where:
- Read (`r`) = 4
- Write (`w`) = 2
- Execute (`x`) = 1
- None (`-`) = 0

Summing values produces single digits (0 through 7):
- `7` = `4+2+1` (rwx: full access)
- `6` = `4+2+0` (rw-: read and write, typical for data files)
- `5` = `4+0+1` (r-x: read and execute, typical for scripts/folders)
- `4` = `4+0+0` (r--: read only)

Common permission configurations:
- `chmod 755 script.sh` -> Owner: read/write/execute (7), Group: read/execute (5), Others: read/execute (5). Standard for executable binaries and scripts.
- `chmod 644 config.conf` -> Owner: read/write (6), Group: read (4), Others: read (4). Standard for system configuration files.
- `chmod 600 id_rsa` -> Owner: read/write (6), Group: none (0), Others: none (0). Required for SSH private keys to prevent unauthorized reading.

## 3. Modifying Ownership with chown
- Change owner: `chown user filename`
- Change owner and group: `chown user:group filename`
- Recursive modification: `chown -R user:group /opt/myapp/`

## 4. Special Directory Permissions
For directories, execute (`x`) permission is required to enter or traverse the directory (`cd` command). Without `x`, files inside cannot be accessed even if they have individual read permissions.