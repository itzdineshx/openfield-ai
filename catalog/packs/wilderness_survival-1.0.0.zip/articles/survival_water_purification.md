# Wilderness Water Sourcing, Filtration & Purification

Humans can survive approximately 3 weeks without food, but only 3 days without water. In wilderness conditions, unpurified water harbors pathogenic protozoa, bacteria, and viruses.

## 1. Biological Contaminants & Target Sizes
- **Protozoan Cysts (Giardia, Cryptosporidium):** 1 to 15 microns. Resistant to standard chlorine tablets; neutralized reliably by boiling or sub-micron ceramic/hollow-fiber membrane filters.
- **Bacteria (E. coli, Salmonella, Cholera):** 0.2 to 2 microns. Removed by 0.1-micron microfilters or heat.
- **Viruses (Hepatitis A, Norovirus, Rotavirus):** 0.02 to 0.1 microns. Too small for mechanical microfilters; neutralized by boiling, UV radiation, or chemical halogens.

## 2. Field Purification Methods
1. **Rolling Boil (The Gold Standard):**
   - Bring water to a vigorous rolling boil for **1 full minute** at sea level.
   - Above 2,000 meters (6,500 feet), boil for **3 full minutes** to compensate for reduced atmospheric pressure and lower boiling points.
2. **Improvised Multi-Layer Biofilter (Clarification):**
   - Cut the bottom off a plastic bottle and invert it.
   - Layer 1 (Bottom): Clean cloth or cotton.
   - Layer 2: Crushed wood charcoal from a campfire (adsorbs organic chemical odors and impurities).
   - Layer 3: Fine clean sand.
   - Layer 4: Coarse sand and gravel.
   - *Note:* Filtering removes suspended sediment and turbidity, but filtered water must still be boiled or chemically treated to kill pathogens.
3. **SODIS (Solar Water Disinfection):**
   - Fill clean, transparent PET bottles with clear water and expose to direct sunlight for **6 hours** (or 2 days if cloudy). UV-A rays and solar thermal heating destroy waterborne pathogens.