# Celestial Navigation Using Crux (Southern Cross) & Polaris

When magnetic compasses or GPS satellite receivers fail, celestial navigation using key circumpolar constellations provides absolute cardinal direction anywhere on Earth.

## 1. Southern Hemisphere: Finding True South via Crux (Southern Cross)
The constellation **Crux** is a distinctive 4-star kite/cross pattern accompanied by two bright "Pointer Stars" (Alpha and Beta Centauri).

### The Projection Method:
1. Locate the four primary stars of the Southern Cross: Acrux (bottom), Gacrux (top), Mimosa (left), and Imai (right).
2. Trace an imaginary straight line extending through the long axis of the cross, from **Gacrux through Acrux**, extending outward **4.5 times** the distance between these two stars.
3. Draw a second line between the two bright **Pointer Stars** (Alpha and Beta Centauri), and construct a perpendicular bisector line from its midpoint.
4. The intersection where the Crux long-axis line meets the Pointer bisector is the **South Celestial Pole (SCP)**.
5. Drop your gaze vertically downward from the South Celestial Pole directly to the horizon: **that point on the horizon is True South**.
6. Turn 180° around to face True North.

## 2. Northern Hemisphere: Finding True North via Polaris
Polaris (the North Star) sits almost directly above the geographic North Pole.

### The Pointer Stars Method:
1. Locate the **Big Dipper** (Ursa Major, the Plough).
2. Find the two outer stars of the bowl furthest from the handle: **Merak** (lower bowl) and **Dubhe** (upper bowl).
3. Draw a straight line from Merak through Dubhe and extend it outward approximately **5 times** the distance between them.
4. You will hit **Polaris**, a moderately bright star situated at the tip of the Little Dipper's handle (Ursa Minor).
5. Drop vertically from Polaris to the horizon: **that point on the horizon is True North**.