# PC Boot Sequence & Hardware Fault Isolation

## 1. Boot Stages
1. **Power Supply On (PS-ON):** Power Good signal asserted (+5V on grey wire) once DC rails (+12V, +5V, +3.3V) stabilize.
2. **UEFI/BIOS POST:** CPU initialization, RAM detection, PCIe bus scanning, GPU initialization.
3. **Bootloader Hand-off:** UEFI locates the EFI System Partition (FAT32) and executes `bootmgfw.efi` (Windows) or `grubx64.efi` (Linux).

## 2. POST Symptoms
- **Fans spin, black screen, continuous beeps:** RAM initialization failure. Reseat memory in slots A2/B2.
- **1 long, 2 short beeps:** GPU or PCIe display initialization failure.