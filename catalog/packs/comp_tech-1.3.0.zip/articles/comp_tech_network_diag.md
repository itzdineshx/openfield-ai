# Network Diagnostics & Connectivity Troubleshooting

Troubleshoot LAN/WAN outages systematically using bottom-up OSI model verification.

## 1. Physical & Link Layer
`ip link show` — Confirm link state is `UP` and carrier is present.
`ip addr show` — Check assigned IP and subnet mask. Ensure not assigned link-local APIPA (`169.254.x.x`).

## 2. Gateway & Routing
`ip route show` — Identify default gateway.
`ping -c 4 <gateway-ip>` — If local gateway responds, local physical link is operational.

## 3. Public WAN & DNS
`ping -c 4 1.1.1.1` — Tests public IP routing without DNS.
`dig @1.1.1.1 google.com +short` — Tests DNS resolver independence.