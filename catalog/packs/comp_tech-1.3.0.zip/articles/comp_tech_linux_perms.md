# Linux File Permissions, Ownership & Access Control Lists

In Unix-like systems, security isolation is enforced via Discretionary Access Control (DAC) assigning permissions across three scopes: User (u), Group (g), and Others (o).

## 1. Octal Representation & Standard Modes
- Read (`r`) = 4, Write (`w`) = 2, Execute (`x`) = 1.
- `chmod 755 binary`: User (rwx = 7), Group (r-x = 5), Others (r-x = 5).
- `chmod 644 config.conf`: User (rw- = 6), Group (r-- = 4), Others (r-- = 4).
- `chmod 600 id_rsa`: User (rw- = 6), Group (--- = 0), Others (--- = 0). Required for private SSH keys.

## 2. Special Permission Bits (SUID, SGID, Sticky)
- **SUID (4000):** Executes with the file owner's privileges (e.g. `/usr/bin/passwd`).
- **SGID (2000):** New files created in directory inherit directory group ownership.
- **Sticky Bit (1000):** Only the file owner or root can delete files within the directory (standard on `/tmp`).