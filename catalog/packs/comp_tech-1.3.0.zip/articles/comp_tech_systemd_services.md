# Systemd Service Units & Journalctl Logging

Systemd manages Linux background daemons, socket activation, and logging.

## 1. Unit Management
```bash
systemctl start service_name
systemctl stop service_name
systemctl restart service_name
systemctl status service_name
systemctl enable --now service_name  # Enable at boot and start immediately
```

## 2. Inspecting Logs with journalctl
```bash
journalctl -u service_name -f        # Follow real-time output
journalctl -u service_name -e        # Jump to end of log buffer
journalctl -p err..emerg -b          # Filter errors since current boot
```