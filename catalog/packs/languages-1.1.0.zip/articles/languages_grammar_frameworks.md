# Core Grammatical Frameworks & Syntactic Structures

## 1. Word Order Typology
- **SVO (Subject-Verb-Object):** English, Mandarin, Spanish.
- **SOV (Subject-Object-Verb):** Japanese, Korean, Hindi, Turkish.
- **VSO:** Arabic, Irish, Classical Hebrew.

## 2. Tense, Aspect, Mood (TAM)
- **Tense:** Past, Present, Future.
- **Aspect:** Simple, Continuous, Perfect.
- **Mood:** Indicative (fact), Subjunctive (wish/counter-factual), Imperative (command).