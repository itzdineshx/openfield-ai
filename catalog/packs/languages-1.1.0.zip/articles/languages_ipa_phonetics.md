# International Phonetic Alphabet (IPA) & Phonetics

The International Phonetic Alphabet provides standard visual representation of speech sounds.

## 1. Consonant Articulation Dimensions
- **Place:** Bilabial (p, b, m), Labiodental (f, v), Alveolar (t, d, s, z), Velar (k, g), Glottal (h).
- **Manner:** Plosive/Stop (p, t, k), Fricative (f, s, z), Nasal (m, n), Approximant (w, j, l).
- **Voicing:** Voiced (vocal cords vibrate) vs Voiceless.