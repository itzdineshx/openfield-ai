# Power Rail Diagnostics & Short Circuit Isolation

Short-circuits on motherboard power rails typically occur when an SMD ceramic capacitor (MLCC) cracks or a MOSFET bridge suffers punch-through breakdown.

## 1. Initial Resistance to Ground Check
1. Switch multimeter to Resistance mode (lowest range: 200Ω).
2. Connect black probe to chassis ground.
3. Probe the output inductor / coil of each major voltage regulator stage:
   - Input Rail (12V or 19V): Normal reading is megaohms or kiloohms. Below 5Ω indicates a dead short.
   - Core Rails (CPU Vcore / GPU Core): Normal reading is naturally low (1Ω - 15Ω) due to high current silicon logic. Do not mistake normal core resistance for a short circuit.
   - 3.3V and 5V Standby Rails: Normal reading is above 100Ω.

## 2. Voltage Injection Fault Isolation Method
1. Set a bench DC power supply to **1.0V** and current limit to **1.0A**.
   - *Crucial Rule:* Never inject voltage higher than the nominal rail rating! For CPU rails, never exceed 1.0V.
2. Solder ground wire to board ground. Solder positive wire to the shorted inductor pad.
3. Slowly raise current limit while monitoring current draw.
4. Locate the defective component:
   - **Thermal Imaging:** The shorted capacitor or MOSFET will glow white-hot immediately.
   - **Isopropyl Alcohol (IPA) Evaporation:** Spray 99% IPA across the board. The shorted component dissipates electrical energy as heat (P = I^2 * R), causing the alcohol on it to evaporate within seconds while surrounding parts remain wet.