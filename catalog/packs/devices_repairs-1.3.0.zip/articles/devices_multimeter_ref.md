# Digital Multimeter (DMM) Master Operating Reference

A digital multimeter is the primary diagnostic instrument in electronics and electrical repair. Using the correct measurement mode and probe placement prevents device damage and ensures accurate readings.

## 1. Test Leads and Jacks
- **Black Probe:** Always plugged into the **COM** (Common/Ground) jack.
- **Red Probe:**
  - Plug into **V/Ω/Hz/Diode** jack for voltage, resistance, frequency, and continuity.
  - Plug into **10A / 20A** unfused/heavy-duty jack only when measuring high current.
  - *Caution:* Never measure voltage while the red lead is plugged into a Current (A/mA) jack, as this creates a direct dead short through the meter's internal shunt resistor!

## 2. Measurement Modes
### A. DC Voltage (V⎓)
- Used for batteries, DC power adapters, logic board power rails (1.8V, 3.3V, 5V, 12V, 19V).
- Black probe to ground (shielding or ground pad); red probe to test point.
- Reading should match expected rail voltage within ±5%.

### B. Continuity Test (Buzzer Mode 🔊)
- Verifies physical conductive paths between two points.
- Meter emits an audible tone when resistance is below ~30 to 50 ohms.
- Always perform continuity checks on **unpowered** circuits. Residual voltage can produce false triggers or blow the meter fuse.
- Used for finding broken traces, damaged ribbon cables, and detecting short-circuits between power rails and ground.

### C. Resistance Mode (Ω)
- Measures component resistance (resistors, heater elements, coils).
- Must be measured with power disconnected. For in-circuit testing, lift one leg of the component if parallel paths distort readings.

### D. Diode Mode (Forward Voltage Drop)
- Meters pass a small current (~1mA) and measure the voltage drop in volts.
- Used for testing PN junctions of silicon diodes and BJT/MOSFET transistors.
  - Normal silicon diode forward drop: `0.55V - 0.70V`. Reverse bias should read `OL` (Open Loop / Over Limit).
  - Schottky diode forward drop: `0.15V - 0.35V`.
  - A reading of `0.00V` in both directions indicates a shorted semiconductor.