# Classical Mechanics & Laws of Conservation

## 1. Newton's Laws
1. **First Law:** Objects remain at constant velocity unless acted upon by a net external force.
2. **Second Law:** $F_{net} = m \cdot a = \frac{dp}{dt}$.
3. **Third Law:** $F_{A \to B} = -F_{B \to A}$.

## 2. Energy Conservation
Mechanical energy $E = E_k + E_p = \text{constant}$ in conservative fields.
- Kinetic: $E_k = \frac{1}{2} m v^2$.
- Gravitational Potential: $E_p = m g h$ ($g \approx 9.81\text{ m/s}^2$).