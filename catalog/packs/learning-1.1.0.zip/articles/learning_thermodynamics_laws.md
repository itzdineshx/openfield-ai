# Laws of Thermodynamics & Heat Engines

## 1. The Fundamental Laws
- **First Law (Conservation of Energy):** $\Delta U = Q - W$, where $\Delta U$ is change in internal energy, $Q$ is heat added, and $W$ is work done by the system.
- **Second Law (Entropy):** The total entropy of an isolated system always increases over time: $\Delta S_{total} \ge 0$.
- **Third Law:** The entropy of a pure crystalline substance approaches zero as temperature approaches absolute zero (0 Kelvin).

## 2. Maximum Carnot Efficiency
$$\eta_{max} = 1 - \frac{T_{cold}}{T_{hot}}$$