# Periodic Table Principles & Chemical Bonding

## 1. Trends
- **Atomic Radius:** Decreases left-to-right across periods; increases down groups.
- **Electronegativity:** Increases left-to-right (Fluorine = 3.98); decreases down groups.

## 2. Bonding
- **Ionic:** Electron transfer between atoms with $\Delta EN > 1.7$ (e.g. NaCl).
- **Covalent:** Shared electron pairs (e.g. H2O, CH4).