# Regular Expressions (Regex) Syntax & Token Guide

Regular expressions define declarative pattern-matching engines over string character sequences.

## 1. Anchors & Boundaries
- `^` : Start of string (or start of line in multiline mode `(?m)`).
- `$` : End of string (or end of line in multiline mode).
- `\b` : Word boundary (transition between `\w` and `\W`).
- `\B` : Non-word boundary.

## 2. Character Classes
- `.` : Any character except newline `\n`.
- `\d` : Digit `[0-9]`.
- `\D` : Non-digit `[^0-9]`.
- `\w` : Word character `[a-zA-Z0-9_]`.
- `\W` : Non-word character.
- `\s` : Whitespace (space, tab, newline `[ \t\r\n\f]`).
- `[a-z0-9]` : Character set range.
- `[^a-z]` : Negated character set.

## 3. Quantifiers (Greedy vs Lazy)
- `*` : 0 or more (greedy).
- `+` : 1 or more (greedy).
- `?` : 0 or 1 (optional).
- `*?` / `+?` : Non-greedy (lazy) matching (stops at earliest match).
- `{n}` : Exactly n times.
- `{n,m}` : Between n and m times.

## 4. Lookaround Assertions (Zero-Width)
- **Positive Lookahead `X(?=Y)`:** Matches `X` only if followed by `Y`.
- **Negative Lookahead `X(?!Y)`:** Matches `X` only if NOT followed by `Y`.
- **Positive Lookbehind `(?<=Y)X`:** Matches `X` only if preceded by `Y`.
- **Negative Lookbehind `(?<!Y)X`:** Matches `X` only if NOT preceded by `Y`.