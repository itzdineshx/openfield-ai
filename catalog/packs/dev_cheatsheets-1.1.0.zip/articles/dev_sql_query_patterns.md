# SQL Query Optimization & Indexing Patterns

Relational databases use B-Tree indexes and Cost-Based Query Optimizers to evaluate execution plans.

## 1. B-Tree Index Mechanics & Sargable Predicates
- An index cannot be utilized if a column is wrapped in an arithmetic expression or non-deterministic function (**Non-Sargable**):
  - *Slow (Full Table Scan):* `SELECT * FROM logs WHERE SUBSTR(timestamp, 1, 10) = '2026-11-20'`
  - *Fast (Index Seek):* `SELECT * FROM logs WHERE timestamp >= '2026-11-20 00:00:00' AND timestamp < '2026-11-21 00:00:00'`

## 2. Covering Indexes
A covering index contains all columns requested by a `SELECT` query in its composite key or `INCLUDE` clause, eliminating expensive table row lookups:
```sql
CREATE INDEX idx_messages_session_time ON messages (sessionId, timestamp, content);
```

## 3. Analyzing Execution Plans in SQLite
```sql
EXPLAIN QUERY PLAN
SELECT id, title FROM documents WHERE mimeType = 'application/pdf';
-- Look for 'SEARCH TABLE ... USING INDEX' (Optimal)
-- Avoid 'SCAN TABLE ...' (Full Table Scan across large tables)
```