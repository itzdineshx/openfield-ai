# Git Version Control Master Reference & Disaster Recovery

Git stores content as an immutable cryptographically hashed directed acyclic graph (DAG) of blob, tree, and commit objects.

## 1. Branch Maintenance & Interactive Rebasing
```bash
# Rebase feature branch on top of latest master without creating merge bubbles
git checkout feature-branch
git fetch origin master
git rebase origin/master

# Interactive rebase of last 5 commits (squash, reword, drop, fixup)
git rebase -i HEAD~5

# Abort an in-flight conflict rebase cleanly without data corruption
git rebase --abort

# Continue rebase after resolving conflict markers
git add <resolved-file>
git rebase --continue
```

## 2. Disaster Recovery with Reflog (Resurrecting Lost Commits)
Git never deletes committed objects immediately; the local `reflog` tracks every pointer shift of `HEAD`:
```bash
# Display chronological history of all HEAD movements
git reflog

# Output example:
# a1b2c3d HEAD@{0}: reset: moving to HEAD~1
# e4f5g6h HEAD@{1}: commit: feat(ai): implement offline tokenizer

# Restore repository to the exact commit prior to an accidental hard reset
git reset --hard HEAD@{1}
```

## 3. Stashing & Cherry-Picking
```bash
# Stash tracked and untracked files with an explicit description
git stash push -u -m "WIP: LiteRT-LM memory optimizer"

# Inspect contents of most recent stash
git stash show -p

# Apply and drop most recent stash
git stash pop

# Cherry-pick a specific commit hash into current active branch
git cherry-pick <commit-sha>
```