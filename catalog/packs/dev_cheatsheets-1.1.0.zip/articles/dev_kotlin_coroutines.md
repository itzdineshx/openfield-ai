# Kotlin Coroutines & Flow Essential Cheat Sheet

Kotlin coroutines provide structured asynchronous programming primitives backed by an event-driven cooperative runtime.

## 1. Dispatcher Architectures
```kotlin
Dispatchers.Main        // Android UI main thread; fast state mutations and view updates
Dispatchers.IO          // Elastic thread pool (up to 64 threads) for blocking SAF file, Room DB, and network I/O
Dispatchers.Default     // Fixed pool sized to CPU core count; optimized for intensive computation, parsing, encryption
Dispatchers.Unconfined  // Starts execution in the current call-frame; resumes in whatever thread the suspension completed
```

## 2. Core Builders & Execution Contexts
```kotlin
// Launch: Fire-and-forget coroutine returning a cancellable Job handle
val job: Job = scope.launch(Dispatchers.Default) {
    doComputation()
}

// Async: Concurrently yields a Deferred<T> result
val deferred: Deferred<Data> = scope.async(Dispatchers.IO) {
    fetchData()
}
val result: Data = deferred.await()

// SupervisorJob: Prevents child failure propagation from cancelling sibling coroutines
val customScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
```

## 3. StateFlow vs SharedFlow Reactive Streams
- **StateFlow<T>:** Hot stream, always caches latest value, replay buffer = 1, conflates identical consecutive values. Ideal for ViewModel UI state.
- **SharedFlow<T>:** Hot stream, configurable replay buffer, emits one-off transient events (navigation commands, snackbar alerts).

```kotlin
private val _state = MutableStateFlow<UiState>(UiState.Idle)
val state: StateFlow<UiState> = _state.asStateFlow()

_state.update { current -> current.copy(isLoading = true) }
```

## 4. Cooperative Cancellation Rules
Coroutines do not terminate forcibly; they cooperatively check cancellation flags:
```kotlin
while (isActive) {
    ensureActive() // Throws CancellationException if job is cancelled
    val chunk = stream.read()
    yield()        // Yields thread time-slice to other pending coroutines
}
```