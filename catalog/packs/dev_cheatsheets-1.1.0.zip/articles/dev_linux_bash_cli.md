# Linux Bash Scripting & Core CLI Power Tools

Bash provides programmable POSIX shell environments for stream processing, automation, and pipeline coordination.

## 1. Robust Scripting Preamble (Defensive Bash)
Always begin production bash scripts with the strict error-handling flag string:
```bash
#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'
```
- `-e`: Exit immediately if any command returns a non-zero exit status.
- `-u`: Treat unset variables as an error and exit immediately.
- `-o pipefail`: Return exit code of the first failing command in a pipeline, rather than only the last command.

## 2. Stream Processing with sed & awk
```bash
# sed: Stream Editor in-place pattern substitution
sed -i -E 's/old_endpoint/new_endpoint/g' config.env

# awk: Field processing (print 1st and 3rd columns from colon-delimited /etc/passwd)
awk -F: '{print $1, $3}' /etc/passwd

# Filter rows where 3rd column exceeds threshold
awk -F, '$3 > 1000 {print $1, $3}' sales_data.csv
```

## 3. Parallel Execution with xargs
```bash
# Find all PDF documents and extract text in parallel across 4 CPU cores
find . -name "*.pdf" -print0 | xargs -0 -P 4 -I {} python extract.py "{}"
```