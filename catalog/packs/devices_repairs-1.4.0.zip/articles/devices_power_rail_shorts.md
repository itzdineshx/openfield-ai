# Power Rail Diagnostics & Short Circuit Isolation

Short-circuits typically arise from cracked ceramic MLCC capacitors or punctured MOSFETs.

## 1. Resistance Check to Ground
- Check resistance of main 12V/19V input rail to ground. Above 100 kΩ is normal. <5Ω is a dead short.
- Core CPU rails naturally measure low resistance (1Ω - 15Ω). Do not confuse core resistance with a short circuit.

## 2. Voltage Injection Technique
- Set bench power supply to 1.0V with 1.0A limit.
- Inject into shorted rail; use isopropyl alcohol evaporation or thermal camera to find the hot component.