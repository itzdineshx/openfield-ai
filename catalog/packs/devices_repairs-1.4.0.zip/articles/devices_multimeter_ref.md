# Digital Multimeter (DMM) Master Operating Reference

## 1. Safety Jack Selection
- **Black Lead:** Always plugged into COM (Ground).
- **Red Lead:** V/Ω/Hz for voltage, resistance, diode checks. Never probe voltage when plugged into 10A current jack!

## 2. Modes
- **DC Voltage:** Measure batteries, rails, logic levels.
- **Continuity:** Beeper sounds when loop resistance <50Ω. Always test on unpowered circuits.
- **Diode Drop:** Silicon diodes drop 0.55V - 0.70V; Schottky drops 0.18V - 0.35V.