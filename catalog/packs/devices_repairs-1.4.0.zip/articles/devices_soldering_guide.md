# Precision Electronics Soldering & Desoldering Procedures

## 1. Soldering Temperatures
- **Leaded (Sn63/Pb37):** Melting point 183°C. Iron tip: **300°C - 320°C**.
- **Lead-Free (SAC305):** Melting point 217°C. Iron tip: **350°C - 370°C**.

## 2. Joint Quality Criteria (IPC-A-610)
- Concave, bright, smooth fillet wetting pad and pin.
- Cold joint: Grainy, dull, globular ball shape caused by insufficient heat or movement while cooling.