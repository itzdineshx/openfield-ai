# SMD Rework & Hot Air Reflow Techniques

## 1. Temperature & Airflow Profiles
- Pre-heat board area to 120°C - 150°C to minimize thermal stress and PCB warping.
- Set hot air nozzle to 350°C - 380°C with moderate air velocity (prevent blowing away adjacent 0402 components).
- Circle nozzle continuously around chip perimeter until solder liquifies.
- Lift straight up with vacuum pickup or precision tweezers.