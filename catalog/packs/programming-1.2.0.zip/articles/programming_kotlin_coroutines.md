# Kotlin Coroutines & Structured Concurrency

Kotlin coroutines provide suspendable primitives that run asynchronous tasks sequentially without thread blocking.

## 1. Hierarchy & Cancellation
Parent coroutines wait for all child jobs. Cancelling a parent recursively cancels children. Use `SupervisorJob` when failures should be isolated.