# Room Database Architecture & Migration Guidelines

Room provides an abstraction layer over SQLite for offline persistence.

## 1. Migration Best Practices
Always provide explicit migration objects:
```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE documents ADD COLUMN pageCount INTEGER NOT NULL DEFAULT 1")
    }
}
```