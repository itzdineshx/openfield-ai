# Clean Architecture & Separation of Concerns

Organize applications into independent layers:
1. **Domain:** Business entities and Use Cases. Free of Android framework dependencies.
2. **Data:** Repositories, DAOs, API clients, and data mappers.
3. **Presentation:** ViewModels, StateFlow, and Composable UI screens.