# Room Database Architecture & Migration Guidelines

Android's Room persistence library provides an abstraction layer over SQLite that allows robust database access while harnessing the full power of SQLite.

## 1. Core Architectural Components
- **Entity:** Represents a table within the database. Annotated with `@Entity(tableName = "name")`. Each persistent property maps to a database column.
- **DAO (Data Access Object):** Defines database interactions using Kotlin functions annotated with `@Query`, `@Insert`, `@Update`, and `@Delete`.
- **Database:** Extends `RoomDatabase`. Lists entities and version number; exposes abstract DAO getters.

## 2. Reactive Data Streams with Flow
DAOs can return `Flow<List<Entity>>`. Room monitors database tables and automatically re-queries and emits fresh snapshots whenever corresponding rows are inserted, updated, or deleted, creating reactive UI pipelines.

## 3. SQLite Migrations
When changing database schemas (adding tables or altering columns), increment the database version and provide a `Migration(start, end)` object:
```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE users ADD COLUMN age INTEGER NOT NULL DEFAULT 0")
    }
}
```
*Best Practice:* Always avoid destructive migrations (`fallbackToDestructiveMigration`) in production releases to prevent user data loss during app updates.