# Kotlin Coroutines & Structured Concurrency

Kotlin coroutines provide lightweight, suspendable execution primitives that run asynchronous code sequentially without blocking the underlying OS thread.

## 1. Core Primitives
- **Suspend Functions:** Marked with the `suspend` keyword. Can yield execution at suspension points without locking the thread.
- **CoroutineScope:** Defines the lifetime and boundaries of coroutines launched within it.
- **Job:** A handle to a coroutine that tracks lifecycle state (Active, Completing, Completed, Cancelled).

## 2. Dispatchers
Dispatchers specify which thread or thread pool executes the coroutine:
- `Dispatchers.Main`: Android main thread. Used strictly for UI updates and small callbacks. Never run disk I/O or heavy computation here.
- `Dispatchers.IO`: Backed by an elastic thread pool optimized for off-loading blocking I/O (file reading/writing, database queries, network operations).
- `Dispatchers.Default`: Optimized for CPU-intensive computation (JSON parsing, image resizing, heavy list transformations).

## 3. Structured Concurrency Principles
Coroutines adhere to hierarchical parent-child relationships:
1. A parent scope does not complete until all its child coroutines finish.
2. Cancelling a parent scope immediately cancels all child jobs recursively.
3. If a child coroutine fails with an uncaught exception, it propagates the failure upward, cancelling sibling coroutines and the parent.
4. **SupervisorJob:** Use a `SupervisorJob()` when child failures should be isolated and not trigger catastrophic cancellation of other tasks (e.g., handling independent network requests).

## 4. Cooperative Cancellation
Coroutines must cooperatively check for cancellation:
- Standard library functions like `delay()`, `yield()`, and `ensureActive()` check `Job.isActive` and throw `CancellationException` when cancelled.
- In CPU-intensive loops, periodically call `ensureActive()` or check `if (!isActive) break`.