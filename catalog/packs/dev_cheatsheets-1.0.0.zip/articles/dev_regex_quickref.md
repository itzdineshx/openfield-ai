# Regular Expressions (Regex) Syntax & Token Guide

## 1. Anchors and Boundaries
- `^` : Start of string (or line in multiline mode).
- `$` : End of string (or line in multiline mode).
- `\b` : Word boundary (transition between word and non-word character).
- `\B` : Non-word boundary.

## 2. Character Classes
- `.` : Any character except newline.
- `\d` : Digit `[0-9]`.
- `\D` : Non-digit `[^0-9]`.
- `\w` : Word character `[a-zA-Z0-9_]`.
- `\s` : Whitespace (space, tab, newline).
- `[a-z]` : Character range.
- `[^a-z]` : Negated character range.

## 3. Quantifiers
- `*` : 0 or more (greedy).
- `+` : 1 or more (greedy).
- `?` : 0 or 1 (optional).
- `*?` / `+?` : Non-greedy (lazy) matching.
- `{n}` : Exactly n times.
- `{n,m}` : Between n and m times.

## 4. Lookaround Assertions (Zero-Width)
- Positive Lookahead: `X(?=Y)` (matches X only if followed by Y).
- Negative Lookahead: `X(?!Y)` (matches X only if NOT followed by Y).
- Positive Lookbehind: `(?<=Y)X` (matches X only if preceded by Y).
- Negative Lookbehind: `(?<!Y)X` (matches X only if NOT preceded by Y).