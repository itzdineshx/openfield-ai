# Git Version Control Master Reference

## 1. Branching & Rebasing
```bash
# Rebase feature branch on top of latest master
git checkout feature
git fetch origin master
git rebase origin/master

# Interactive rebase last 4 commits (squash, edit, reword)
git rebase -i HEAD~4

# Abort an in-flight conflict rebase cleanly
git rebase --abort
```

## 2. Disaster Recovery with Reflog
Git never deletes committed objects immediately. The `reflog` tracks every HEAD movement:
```bash
# View chronological history of HEAD changes
git reflog

# Restore branch to state before an accidental reset or deleted branch
git reset --hard HEAD@{3}
```

## 3. Stashing & Cherry-Picking
```bash
# Stash untracked and modified files with description
git stash push -u -m "WIP: offline parser"

# Apply and drop most recent stash
git stash pop

# Pick specific commit into current branch
git cherry-pick <commit-sha>
```