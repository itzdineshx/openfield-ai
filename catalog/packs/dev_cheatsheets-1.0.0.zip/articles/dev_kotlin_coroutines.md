# Kotlin Coroutines & Flow Essential Cheat Sheet

## 1. Builders and Dispatchers
```kotlin
// Launch fire-and-forget job
val job = scope.launch(Dispatchers.Default) { ... }

// Async with deferred result
val deferred = scope.async(Dispatchers.IO) { fetchData() }
val data = deferred.await()

// Dispatcher Selection
Dispatchers.Main        // UI operations & LiveData/StateFlow emission
Dispatchers.IO          // Network requests, Room DB, SAF file I/O (elastic thread pool)
Dispatchers.Default     // Heavy CPU calculation, JSON parsing, image downsampling
Dispatchers.Unconfined  // Starts on caller thread, resumes on suspension thread
```

## 2. StateFlow vs SharedFlow
- **StateFlow:** Hot stream, always holds one state value, replay cache of 1, conflates duplicate values, ideal for UI state (`val state = _state.asStateFlow()`).
- **SharedFlow:** Hot stream, zero default replay, ideal for one-off events (navigation, toast, snackbar).

## 3. Cooperative Cancellation
Coroutines are cooperatively cancellable. Always verify `isActive` or call `yield()` in CPU loops:
```kotlin
while (isActive) {
    // Process chunk
    ensureActive() // Throws CancellationException if job is cancelled
}
```