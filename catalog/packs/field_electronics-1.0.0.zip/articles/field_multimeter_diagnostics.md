# Digital Multimeter Diagnostics & Component Testing

A digital multimeter (DMM) is the primary diagnostic instrument for troubleshooting unpowered and powered electronic assemblies.

## 1. Core Operating Modes
- **DC Voltage (V=):** Measures steady potential difference. Red probe to circuit node, black probe to common ground (GND). Use for verifying battery charge, power supplies, and logic rails (3.3V, 5V, 12V).
- **Continuity (Beeper):** Emits an audible tone when loop resistance is below approximately 30Ω - 50Ω. Used for tracing broken PCB tracks, blown fuses, and finding solder bridges.
- **Resistance (Ω):** Measures passive component impedance without power applied. Always isolate at least one pin of a resistor when testing in-circuit to avoid parallel paths.
- **Diode Mode:** Injects a constant current (~1mA) and displays the forward voltage drop (V_f):
  - Silicon PN Junction: 0.5V to 0.7V.
  - Schottky Diode: 0.15V to 0.35V.
  - Germanium Diode: 0.2V to 0.3V.
  - Open or Reverse Biased: "OL" (Over Limit).
  - Shorted Diode: 0.00V in both directions.

## 2. In-Circuit Capacitor Testing
1. Disconnect all power and safely discharge high-voltage electrolytic capacitors through a 1kΩ 5W power resistor.
2. In Resistance mode, connect probes across the capacitor:
   - Reading should start low, then continuously climb toward infinity (OL) as the internal DMM battery charges the capacitor.
   - If resistance stays near 0Ω: Capacitor is shorted internally (common failure mode of ceramic MLCCs).

## 3. MOSFET and BJT Transistor Quick Tests
- **NPN BJT:** With meter in Diode Mode, black probe on Base, red probe on Collector and Emitter should read OL. Red probe on Base, black probe on Collector and Emitter should both read ~0.65V.
- **N-Channel MOSFET:** Black probe on Source, red probe on Drain reads ~0.5V (internal body diode). Reverse should read OL. Touch red probe to Gate, then red probe to Drain: MOSFET should conduct (reading drops to 0.0V).