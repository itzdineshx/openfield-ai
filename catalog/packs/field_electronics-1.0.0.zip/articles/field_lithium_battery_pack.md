# Lithium-Ion & LiFePO4 Battery Pack Diagnostics

Lithium secondary cells store high chemical energy density. Proper cell balancing, cutoff voltages, and Battery Management System (BMS) diagnostics are critical to avoid thermal runaway.

## 1. Operating Voltage Thresholds per Cell
| Chemistry | Nominal Voltage | Full Charge (Cutoff) | Storage Voltage | Absolute Minimum (Discharged) |
|---|---|---|---|---|
| **Li-Ion (NMC / Cobalt)** | 3.6V - 3.7V | 4.20V ± 0.05V | 3.82V | 2.80V (Below 2.5V damages cell) |
| **LiFePO4 (Iron Phosphate)**| 3.2V | 3.65V ± 0.05V | 3.30V | 2.50V (Extremely safe chemistry) |
| **Li-Po (Pouch Cells)** | 3.7V | 4.20V (4.35V LiHV) | 3.85V | 3.00V |

## 2. Common Battery Pack Failure Modes
1. **Cell Imbalance in Series Strings (e.g. 3S, 4S, 7S):**
   - Measure each cell via balance connector. Imbalance greater than **50mV (0.05V)** reduces effective capacity. Imbalance over **200mV** trips BMS shutdown.
   - Rebalance using a dedicated balance charger or CC-CV single cell supply.
2. **BMS Lockout State:**
   - Many BMS boards enter protection mode if any single cell drops below 2.5V or shorts.
   - To reset a tripped BMS: Connect appropriate charging voltage across the main P+ and P- terminals for 5 seconds to re-engage the discharge MOSFETs.
3. **Physical Swelling & Dendrites:**
   - Any pouch cell showing gas swelling ("pillowing") has suffered electrolyte decomposition. Discontinue use immediately; do not puncture.