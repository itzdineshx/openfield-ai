# Cardiopulmonary Resuscitation (CPR) & Airway Obstruction

When a casualty is unresponsive with absent or abnormal breathing (agonal gasps), high-quality CPR provides critical coronary and cerebral perfusion pressure until spontaneous circulation returns or defibrillation occurs.

## 1. Initial Assessment Protocol (DRSABCD)
1. **D - Danger:** Ensure the environment is safe from electrical hazards, toxic gas, fire, and unstable structures.
2. **R - Response:** Firmly tap shoulders and shout loudly into both ears: "Are you okay? Open your eyes!"
3. **S - Send for Help:** Dial emergency dispatch (112, 911) or point directly at a bystander: "You in the blue jacket, call emergency services and find an AED!"
4. **A - Airway:** Perform the head-tilt/chin-lift maneuver (or jaw-thrust without neck extension if cervical spinal injury is suspected). Inspect mouth for visible obstructions; clear solids with a finger sweep.
5. **B - Breathing:** Look, listen, and feel for normal chest rise for 5 to 10 seconds. Agonal gasps (infrequent, irregular snorting) must be treated as cardiac arrest.
6. **C - CPR (Compressions):** Immediately place the casualty supine on a firm, flat surface and initiate chest compressions.
7. **D - Defibrillation:** Apply an Automated External Defibrillator (AED) as soon as it arrives without interrupting compressions.

## 2. High-Quality Chest Compression Metrics (AHA / ERC Standard)
- **Hand Position:** Heel of dominant hand centered on the lower half of the sternum; second hand interlocked over the first. Keep elbows locked straight with shoulders positioned directly above hands.
- **Compression Depth:** 5 to 6 cm (2 to 2.4 inches) in adults. Never exceed 6 cm.
- **Compression Rate:** 100 to 120 compressions per minute (approximate tempo of "Stayin' Alive" or 2 beats per second).
- **Complete Chest Recoil:** Allow the chest to fully return to resting neutral position between compressions. Leaning on the chest impairs venous refill and reduces cardiac output by up to 35%.
- **Compression-to-Ventilation Ratio:** 30 compressions to 2 rescue breaths (each delivered over 1 second, watching for chest rise). If untrained or without a barrier mask, deliver **Continuous Hands-Only CPR**.
- **Rescuer Fatigue Rotation:** Switch compressors every 2 minutes (every 5 cycles of 30:2) to maintain compression depth.

## 3. Automated External Defibrillator (AED) Operations
1. Power on the AED immediately.
2. Expose the bare chest; wipe dry with a cloth if wet.
3. Apply self-adhesive electrode pads:
   - Upper Right: Below right clavicle, lateral to sternum.
   - Lower Left: Mid-axillary line, 5th intercostal space below the left pectoral.
   - *Special Conditions:* If an implanted pacemaker/defibrillator bulge is visible, place pad at least 2.5 cm (1 inch) away. Shave excessive chest hair if pads fail to adhere.
4. Clear casualty while the AED analyzes cardiac rhythm.
5. If shock is advised: Shout "Clear!", ensure no one touches the casualty, and press the flashing shock button.
6. **Immediately resume chest compressions** starting with 30 compressions; do not pause to check pulse.

## 4. Foreign Body Airway Obstruction (Choking)
- **Partial/Mild Obstruction (Casualty can speak, cough vigorously):** Encourage coughing. Do not deliver back blows or thrusts while they are coughing effectively.
- **Complete/Severe Obstruction (Cannot speak, silent panic, universal distress sign clutching throat):**
  1. Stand behind casualty, support chest with one arm, and lean them forward.
  2. Deliver **5 sharp back blows** between the shoulder blades using the heel of your hand.
  3. If unrelieved, place the thumb side of your fist midway between the navel and xiphoid process. Grasp fist with your other hand and deliver **5 rapid inward and upward abdominal thrusts (Heimlich maneuver)**.
  4. Repeat cycle of 5 back blows and 5 abdominal thrusts.
  5. If casualty collapses unconscious: Lower them gently to the floor, call emergency dispatch, and initiate CPR (starting with chest compressions). Check airway before rescue breaths.