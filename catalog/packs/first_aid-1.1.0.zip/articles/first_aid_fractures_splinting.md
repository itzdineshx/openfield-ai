# Fractures, Dislocations & Field Splinting

Immobilizing skeletal trauma prevents bone fragments from lacerating adjacent neurovascular bundles, reduces muscle spasm, minimizes blood loss, and prevents closed injuries from converting to open fractures.

## 1. Classification
- **Closed Fracture:** Skin barrier remains intact over the fracture site.
- **Open (Compound) Fracture:** Bone pierces through the skin or an external wound communicates with the fracture hematoma. High risk of osteomyelitis; cover bone with sterile moist gauze; do NOT push exposed bone back inside.
- **Dislocation:** Complete displacement of bone ends forming a joint.

## 2. Neurovascular Protocol (PMS Pre- and Post-Splint Assessment)
Always verify and document **PMS** distally before and immediately after applying any splint or bandage:
1. **P - Pulse:** Check distal arterial pulsation (radial pulse for upper limb; dorsalis pedis / posterior tibial for lower limb). Compare bilaterally.
2. **M - Motor:** Test voluntary distal muscular activation ("Wiggle your fingers", "Flex your toes toward your nose").
3. **S - Sensory:** Lightly touch the casualty's distal digits with eyes closed ("Which finger am I touching?").
- *Critical finding:* If a pulse disappears after splinting, immediately loosen the splint bindings and readjust.

## 3. The 5 Ps of Compartment Syndrome (Orthopedic Emergency)
Elevated pressure within a closed osteofascial compartment compromises capillary perfusion:
1. **Pain:** Disproportionate to injury and refractory to analgesics; exacerbated by passive stretch of muscles.
2. **Pallor:** Pale, cool extremity with prolonged capillary refill.
3. **Paresthesia:** "Pins and needles" or numbness along nerve pathways.
4. **Paralysis:** Inability to actively contract compartment muscle groups (late sign).
5. **Pulselessness:** Absence of distal pulse (late sign indicating impending tissue death).

## 4. Fundamental Rules of Splinting
- **Immobilize the Joint Above and Joint Below:** To splint a tibial shaft fracture, immobilize both the knee and ankle. To splint a radial/ulnar shaft fracture, immobilize both the wrist and elbow.
- **Pad all Bony Prominences:** Cushion rigid splint material (boards, SAM splints, branches) with soft clothing or gauze around the malleoli, patella, and olecranon to avoid pressure necrosis.
- **Splint in the Position Found:** Do not attempt to force a deformed or dislocated joint into anatomical position in the field unless distal pulse is absent and definitive evacuation is delayed hours.