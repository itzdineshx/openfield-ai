# Burn Classification, Fluid Staging & Treatment

Prompt thermal deceleration and infection prophylaxis determine survival and functional recovery after major thermal, electrical, or chemical injuries.

## 1. Depth Staging
- **Superficial (1st Degree):** Confined to epidermis. Erythematous, dry, blanchable, hypersensitive, no bullae (blisters). Heals in 3 to 6 days without scarring.
- **Partial-Thickness (2nd Degree):** Extends into dermis.
  - *Superficial Partial:* Wet, clear blister formation, intensely painful, pink/mottled base.
  - *Deep Partial:* White/pale base, impaired sensation, variable capillary refill.
- **Full-Thickness (3rd Degree):** Complete destruction of epidermis and dermis into subcutaneous fat. Leathery, charred black or pearly waxy white, dry, non-blanching, anesthetic (painless) at the central burn core due to nerve terminal necrosis.
- **4th Degree:** Extends through deep fascia into underlying skeletal muscle, tendon, and cortical bone.

## 2. Rule of Nines (Adult Total Body Surface Area - TBSA Estimation)
- Head and Neck: 9%
- Anterior Torso (Chest + Abdomen): 18%
- Posterior Torso (Back + Buttocks): 18%
- Each Upper Extremity (Arm): 9% (18% both)
- Each Lower Extremity (Leg): 18% (36% both)
- Perineum/Genitalia: 1%
- Palmar Surface of Casualty's Hand (including fingers): approximately 1% TBSA (useful for scattered burns).

## 3. Acute On-Scene Management
1. **Stop the Burning Process:** Extinguish flames (Stop, Drop, Roll), isolate electrical current before touching casualty, or brush off dry chemical powders before irrigation.
2. **Active Thermal Deceleration (20-Minute Clean Water Rule):**
   - Cool the burn using clean, cool running water (15°C to 20°C) for **at least 20 minutes**.
   - Must be initiated within 3 hours of injury to reduce depth of tissue necrosis.
   - *Contraindication:* **Never use ice or freezing water.** Extreme cold induces reflex peripheral vasoconstriction, deepening the thermal burn into ischemic necrosis and causing severe hypothermia.
3. **Constrictive Item Removal:** Remove jewelry, watches, rings, belts, and boots immediately before massive third-space capillary leak edema develops.
4. **Wound Dressing:** Cover loosely with clean, non-adherent sterile dressings or clear food-grade polyethylene cling wrap applied longitudinally (never circumferential wrapping, which creates a tourniquet effect as tissue swells).
5. **Core Temperature Preservation:** Once cooled, wrap unburned body surfaces in clean, dry blankets to combat severe post-burn hypothermia.

## 4. Inhalation Injury Red Flags
Suspect airway burns in closed-space fires. Look for: singed facial/nasal hairs, carbonaceous sputum, hoarseness, inspiratory stridor, and pharyngeal edema. Requires immediate emergency transport and early endotracheal intubation before complete laryngeal closure.