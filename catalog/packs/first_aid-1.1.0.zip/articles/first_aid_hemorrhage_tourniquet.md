# Massive Hemorrhage Control & Tourniquet Application

Uncontrolled arterial hemorrhage can cause irreversible hypovolemic shock and exsanguination in under 180 seconds. In tactical and remote trauma, stopping severe external bleeding precedes all other interventions.

## 1. Classifying External Hemorrhage
- **Arterial Bleeding:** Bright red blood spurting pulsatile under high hydraulic pressure. Highest immediate fatality risk.
- **Venous Bleeding:** Dark red blood flowing steadily without pulsations. Can still lead to rapid exsanguination from large junctional veins (e.g., femoral, jugular).
- **Capillary Bleeding:** Oozing blood from superficial dermis; self-limiting via clotting cascade.

## 2. Stepwise Hemostasis Hierarchy (TCCC MARCH Algorithm)
1. **Direct Manual Pressure:**
   - Press both hands directly onto the bleeding vessel with full body weight.
   - Use sterile gauze, a clean cloth, or gloved fingertips pushed deep into the wound track.
2. **Windlass Tourniquet (Limb Extremities):**
   - The primary intervention for severe extremity trauma, partial/complete amputations, or complex fractures with vascular involvement.
3. **Wound Packing (Junctional Wounds - Groin, Axilla, Neck Base):**
   - Tourniquets cannot occlude junctional vessels. Pack hemostatic gauze (Kaolin-impregnated QuikClot or Chitosan Celox) or plain gauze deep into the wound cavity directly against the bleeding vessel.
   - Pack tightly until the wound void is completely filled.
   - Maintain continuous direct pressure over the pack for **3 full minutes** (5 minutes for non-hemostatic standard gauze).
   - Secure with a pressure bandage (e.g., Israeli Emergency Bandage).

## 3. Combat Application Tourniquet (CAT) Standard Operating Procedure
1. **Placement:**
   - In active emergency/darkness: Place "high and tight" on the proximal limb over clothing.
   - Once bleeding site is clearly exposed: Place **5 to 7 cm (2 to 3 inches) above the proximal bleeding wound**, directly on bare skin. Never place directly over a joint (elbow or knee).
2. **Routing:** Thread self-adhering band through the friction buckle and pull as tightly as humanly possible before engaging the windlass rod. Eliminating slack in this step is critical.
3. **Windlass Tightening:** Twist the windlass rod until bright red arterial bleeding ceases completely and the distal peripheral pulse vanishes.
4. **Locking:** Clip the windlass rod into the retaining C-hook and pull the windlass strap across to lock it in place.
5. **Time Documentation:** Clearly write the exact time of application on the white time tag (e.g., "T = 14:35").

## 4. Critical Safety Rules & Myths
- **Never loosen or intermittently release a tourniquet:** Periodic loosening reintroduces arterial blood loss and washes out clotting factors while failing to save ischemic tissue. A tourniquet can remain safely applied for up to **2 hours** without significant risk of permanent nerve or muscle ischemia.
- **Pain is Expected:** A properly applied tourniquet causes intense pain due to arterial occlusion. Do not loosen it because the casualty complains of pain.
- **Secondary Tourniquet:** If bleeding does not stop completely with one tourniquet, apply a second tourniquet immediately proximal (above) the first.