# Environmental Emergencies: Heat Stroke & Hypothermia Staging

Thermal dysregulation occurs when metabolic heat production and environmental heat transfer overwhelm the body's thermoregulatory mechanisms in the hypothalamus.

## 1. Heat Illness Spectrum
### A. Heat Exhaustion
- Core temperature <40°C (<104°F).
- Symptoms: Profuse diaphoresis (sweating), nausea, headache, tachycardia, orthostatic lightheadedness.
- Mental Status: **Intact**. Casualty is oriented.
- Field Treatment: Move to shade, loosen clothing, elevate legs, sip cool electrolyte fluid.

### B. Exertional / Classic Heat Stroke (Life-Threatening Emergency)
- Core body temperature **>40°C (>104°F)**.
- Key Diagnostic Differentiator: **Altered Mental Status (CNS dysfunction)**: Confusion, delirium, ataxia, seizures, or coma.
- Skin: Can be hot and dry, but exertional victims are often still sweating profusely.
- **Field Treatment (Cool First, Transport Second):**
  - **Cold Water Immersion (Gold Standard):** Submerge casualty up to neck in ice water bath with continuous stirring. Reduces core temp by 0.2°C per minute.
  - If immersion is unavailable: Strip clothing, continuously pour water over body, vigorously fan, and place ice packs at high-perfusion areas (axillae, groin, neck).
  - Target: Cool rapidly until core temp reaches 38.5°C (101.3°F), then halt active cooling to prevent hypothermic overshoot.

## 2. Hypothermia Staging (Swiss Staging System)
- **Stage I - Mild (32°C to 35°C):**
  - Conscious, shivering violently, normal or mildly impaired coordination, tachycardic.
  - Management: Passive rewarming (dry clothing, windproof shell, warm sweet non-caffeinated drinks).
- **Stage II - Moderate (28°C to 32°C):**
  - Shivering ceases, apathy, confusion, severe muscle rigidity, dilated pupils.
  - Management: Active external rewarming of trunk (chemical heat pads on chest and back; never on bare extremities).
- **Stage III - Severe (24°C to 28°C):**
  - Unconscious, profound bradycardia, hypotension, barely perceptible respirations.
  - Management: Full body insulation, gentle handling.
- **Stage IV - Apparent Death (<24°C):**
  - Asystole or pulseless electrical activity. "A casualty is not dead until warm and dead." Initiate prolonged CPR until rewarming can occur in a medical facility.

## 3. The "Afterdrop" Phenomenon
When cold, stagnant blood from vasoconstricted extremities returns suddenly to the core during rapid limb rewarming, it causes a sharp secondary temperature drop in the myocardium, frequently inducing fatal Ventricular Fibrillation (VF). Always warm the central trunk (chest, abdomen) first, and never massage or vigorously rub cold extremities.