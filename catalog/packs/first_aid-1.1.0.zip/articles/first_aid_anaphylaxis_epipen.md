# Anaphylaxis Recognition & Epinephrine Auto-Injector Administration

Anaphylaxis is a severe, systemic, life-threatening type-I hypersensitivity reaction involving massive histamine release, vasodilation, airway bronchoconstriction, and distributive shock.

## 1. Clinical Recognition Criteria
Anaphylaxis is highly likely when any **one** of the following criteria is met following allergen exposure (stings, nuts, shellfish, medications):
1. **Acute skin/mucosal symptoms** (generalized hives, pruritus, facial edema, swollen lips/tongue/uvula) **PLUS at least one of:**
   - Respiratory compromise: Dyspnea, wheezing, stridor, hypoxemia.
   - Hypotension / End-organ dysfunction: Syncope, collapse, diaphoresis, incontinence.
2. **Two or more symptoms occurring rapidly after exposure:**
   - Cutaneous: Urticaria, flushing, angioedema.
   - Respiratory: Throat tightness, coughing, bronchospasm.
   - Cardiovascular: Tachycardia, hypotension, dizziness.
   - Gastrointestinal: Severe abdominal cramps, persistent vomiting.

## 2. Epinephrine: The Sole First-Line Pharmacotherapy
- **Dose:**
  - Adults and children >30 kg: **0.3 mg** intramuscularly (IM).
  - Pediatric 15 to 30 kg: **0.15 mg** intramuscularly (IM).
- **Injection Site:** **Anterolateral middle-third of the thigh (Vastus Lateralis muscle)**.
  - Epinephrine must NEVER be given subcutaneously or into the gluteal muscle; vastus lateralis vascularity provides the most rapid therapeutic plasma peak (under 8 minutes).
  - Can be injected directly through clothing/jeans if necessary.

## 3. Step-by-Step Auto-Injector Administration
1. Form a fist around the injector (never place thumb over either end).
2. Remove the safety release cap (usually blue or yellow at the top).
3. Position the orange/black needle tip perpendicular (90°) against the outer thigh.
4. Push down firmly until a loud click is heard or felt.
5. **Hold firmly in place for 3 to 10 seconds** to ensure complete drug delivery.
6. Remove unit and gently massage the injection site for 10 seconds.
7. Record time of delivery and keep used device to give to paramedics.

## 4. Secondary Dosing and Posture
- **Refractory Symptoms:** If symptoms fail to improve or deteriorate within **5 to 15 minutes**, administer a second dose of epinephrine in the opposite thigh.
- **Patient Positioning:** Keep casualty supine with legs elevated to maintain venous return. Do NOT allow an anaphylactic patient to stand up or walk; sudden upright posture can cause catastrophic pulseless electrical activity (Empty Heart Syndrome). If vomiting or in respiratory distress, place in recovery position or seated upright.