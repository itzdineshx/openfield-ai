# Snakebite Envenomation & Pressure Immobilization (PIT)

Venomous snakebites deliver complex biochemical cocktails of neurotoxins, hemotoxins, cytotoxins, and myotoxins into the subcutaneous lymphatic system. Correct field stabilization prevents systemic distribution.

## 1. Toxin Classifications
- **Neurotoxic (Elapids - Cobras, Kraits, Coral Snakes, Mambas, Australian Elapids):** Blocks neuromuscular junctions. Causes ptosis (drooping eyelids), diplopia, dysphagia, progressive flaccid paralysis, and respiratory failure.
- **Hemotoxic & Cytotoxic (Viperids - Rattlesnakes, Vipers, Pit Vipers, Adders):** Destroys vascular endothelium, consumes fibrinogen (consumptive coagulopathy), causes massive local edema, bullae formation, necrosis, and systemic hemorrhage.

## 2. The Pressure Immobilization Technique (PIT)
*Recommended for all neurotoxic elapid bites and Australian venomous species. Slows lymphatic flow without occluding arterial blood supply.*

1. Apply a broad elastic roller bandage (10 to 15 cm wide) directly over the bite site as firmly as for a sprained ankle (approx. 40 to 70 mmHg pressure).
2. Extend the wrap continuously all the way down the limb (to fingers or toes) and then back up the limb to the groin or axilla.
3. Check distal pulse: Circulation must remain intact; digits must not turn cold, pale, or cyanotic.
4. Apply a rigid splint to immobilize the entire limb.
5. **Absolute Physical Rest:** The casualty must NOT walk, move, or contract muscles; lymphatic valves are driven by skeletal muscle contraction. Carry the casualty or arrange immediate air evacuation.

## 3. Critical Contraindications (Harmful Myths to Avoid)
- **DO NOT apply an arterial tourniquet for snakebites:** High pressure causes localized ischemic necrosis and massive tissue loss.
- **DO NOT cut or incise the fang punctures:** Introduces secondary bacterial infections, causes severe local arterial bleeding, and does not extract venom.
- **DO NOT attempt mouth or mechanical device suction:** Less than 0.1% of venom is aspirated, and mouth bacteria contaminate the puncture.
- **DO NOT apply ice or electric shocks:** Cryotherapy exacerbates local necrosis and permanent tissue destruction.
- **DO NOT attempt to capture or kill the snake:** Avoids secondary bites; take a digital photo from a safe distance (minimum 2 meters) for anti-venom matching.