# Core Grammatical Frameworks & Syntactic Structures

Language structure relies on systematic patterns of words, morphemes, and clauses that govern meaning and communicative clarity.

## 1. Syntactic Typology
Languages differ in canonical word order for transitive sentences (Subject, Verb, Object):
- **SVO (Subject-Verb-Object):** English, Mandarin Chinese, Spanish, Russian. (e.g., "The engineer designed the circuit").
- **SOV (Subject-Object-Verb):** Japanese, Korean, Hindi, Turkish, Latin. (e.g., "The engineer the circuit designed").
- **VSO (Verb-Subject-Object):** Standard Arabic, Irish, Classical Hebrew.

## 2. Verb Tense, Aspect, and Mood (TAM)
- **Tense:** Locates an action in time relative to the speech event (Past, Present, Future).
- **Aspect:** Expresses how the action extends over time:
  - *Simple:* Complete fact ("I wrote the report").
  - *Continuous/Progressive:* Ongoing activity ("I was writing the report").
  - *Perfect:* Completed state with continuing relevance ("I have written the report").
- **Mood:** The speaker's attitude toward the event:
  - *Indicative:* Expressing factual statements ("It is raining").
  - *Subjunctive:* Expressing hypothesis, wish, or counter-factuality ("If I were in your position...").
  - *Imperative:* Expressing commands or requests ("Close the terminal").

## 3. Technical Translation & Register
When translating technical literature across languages:
- Maintain terminology consistency: Map technical definitions to standardized international glossaries (e.g., ISO, IEEE).
- Beware of **False Friends (Cognates):** Words in different languages that look similar but carry divergent meanings (e.g., Spanish *actual* means "current/present", not English "actual/real").