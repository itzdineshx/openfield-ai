# Thermal Debris Shelters & Conduction Loss Prevention

In severe weather, hypothermia can kill within 3 hours. The body loses thermal energy via four mechanisms: Conduction (contact with cold ground), Convection (wind chill stripping boundary layer), Radiation, and Evaporation.

## 1. The Debris Hut (Solo Survival Shelter)
*The most thermally efficient primitive shelter; requires no cordage or tools.*

1. **Ridgepole Selection:** Select a sturdy, dry log 3 to 3.5 meters (10 to 12 feet) long. Prop one end on a stump or rock fork approximately 1 meter off the ground.
2. **Bed Insulation (Critical Step):**
   - The cold ground conducts body heat away **24 times faster** than stationary air.
   - Pile dry leaves, pine needles, dried moss, or grass at least **60 cm to 90 cm (2 to 3 feet) deep** under the ridgepole. Compress it with your body to ensure at least 20 cm of compacted dead air space remains between you and the earth.
3. **Ribbing / Framing:** Lean sturdy sticks along both sides of the ridgepole at a 45° angle to create an A-frame skeleton. Keep the interior space narrow (a debris hut should fit your body like a sleeping bag).
4. **Lattice Layer:** Place smaller brush, branches, and twigs over the ribbing to prevent loose debris from falling through.
5. **Thermal Insulation Layer:**
   - Pile dry leaves, pine needles, and forest debris over the entire structure to a minimum thickness of **1 meter (3 feet)**.
   - Test: Push your arm into the pile up to your shoulder; if you touch the rib sticks before your armpit, the insulation is too thin.
6. **Entrance Stopper:** Gather a large bundle of leaves or a backpack to plug the entrance hole once inside, trapping body heat.