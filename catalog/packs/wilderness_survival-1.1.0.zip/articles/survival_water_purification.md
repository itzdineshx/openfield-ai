# Wilderness Water Sourcing, Multi-Stage Filtration & Purification

Dehydration impairs cognitive judgment within 24 hours and becomes fatal in approximately 72 hours. Untreated surface water harbors biological pathogens capable of causing debilitating dysentery, cholera, and cryptosporidiosis.

## 1. Biological Contaminants Spectrum
- **Protozoan Cysts (Giardia lamblia, Cryptosporidium parvum):** 1 to 15 microns. Outer shell is impervious to standard chlorine and halogen tablets. Neutralized reliably by boiling or sub-micron mechanical microfilters.
- **Bacteria (Escherichia coli, Salmonella, Vibrio cholerae):** 0.2 to 2 microns. Removed by 0.1-micron hollow-fiber membrane filters or pasteurization.
- **Enteric Viruses (Hepatitis A, Norovirus, Rotavirus):** 0.02 to 0.1 microns. Too small for standard 0.1-micron wilderness backpacking microfilters. Neutralized by boiling, UV radiation, or chemical oxidizing agents.

## 2. Field Purification Methods
### A. The Vigorous Rolling Boil (Gold Standard)
- Bring water to a full, turbulent rolling boil for **1 complete minute** at sea level.
- At altitudes above 2,000 meters (6,500 feet), boil for **3 complete minutes** because lower atmospheric pressure reduces the boiling temperature of water (down to ~93°C).
- Kills 100% of all protozoa, bacteria, and viral pathogens.

### B. Improvised 4-Stage Charcoal Biofilter (Turbidity Clarification)
*Turbid, muddy water shields pathogens from chemical and UV treatment. Filter water before purifying.*
1. Invert a clean 1-liter PET plastic bottle with the bottom cut off.
2. **Layer 1 (Bottom/Neck):** Clean cotton cloth or porous sphagnum moss.
3. **Layer 2:** Crushed hardwood charcoal from campfire remnants (not briquettes with binders). Charcoal adsorbs agricultural chemicals, heavy organic toxins, and eliminates foul odors.
4. **Layer 3:** Fine, washed river sand (traps micro-particulates).
5. **Layer 4 (Top):** Coarse sand and small pea gravel (traps suspended silt, leaves, and debris).
- *Warning:* Filtered water is clarified of sediment, but MUST still be boiled or chemically treated to kill microscopic pathogens.

### C. SODIS (Solar Water Disinfection)
1. Fill clean, un-scratched transparent PET bottles with clear water (turbidity <30 NTU).
2. Expose bottles horizontally on a dark or reflective corrugated iron surface in direct sunlight for **at least 6 hours** (or 2 full days under overcast skies).
3. Synergistic action of UV-A radiation (320-400 nm) and elevated water temperature (>50°C) destroys pathogen DNA.