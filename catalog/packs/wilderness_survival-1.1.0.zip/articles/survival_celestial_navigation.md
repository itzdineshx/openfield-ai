# Celestial Navigation Using Crux (Southern Cross) & Polaris

When magnetic compasses suffer needle dip or GPS satellite receivers exhaust battery reserves, circumpolar star constellations provide an unjammable directional reference anywhere on Earth.

## 1. Southern Hemisphere: True South via Constellation Crux (The Southern Cross)
The constellation **Crux** is the smallest yet most distinctive constellation in the southern celestial hemisphere, accompanied by two brilliant Pointer Stars (Alpha and Beta Centauri).

### The Geometric Projection Method:
1. Identify the four primary stars forming the kite/cross pattern:
   - **Gacrux (Gamma Crucis):** Orange giant star at the top of the cross.
   - **Acrux (Alpha Crucis):** Blue-white binary star at the base/foot of the cross.
   - **Mimosa (Beta Crucis):** Eastern arm star.
   - **Imai (Delta Crucis):** Western arm star.
2. Trace an imaginary line along the long axis from **Gacrux through Acrux**, and extend it outward straight into the sky for **4.5 times** the distance between Gacrux and Acrux.
3. Locate the two bright **Pointer Stars** (Alpha and Beta Centauri). Draw a straight line connecting them, find the midpoint, and project a perpendicular bisector line outward.
4. The intersection where the 4.5× Crux extension line meets the Pointer bisector line marks the **South Celestial Pole (SCP)**.
5. Drop your line of sight vertically downward from the South Celestial Pole directly to the horizon: **that exact point on the horizon is True South**.
6. Face True South: East is 90° to your left, West is 90° to your right, and North is directly behind you (180°).

## 2. Northern Hemisphere: True North via Polaris (The North Star)
Polaris lies within 0.7° of the true north celestial pole.

### The Big Dipper Pointer Method:
1. Locate **Ursa Major** (the Big Dipper / Plough).
2. Identify the two outer stars of the cup furthest from the handle: **Merak** (lower bowl) and **Dubhe** (upper lip).
3. Draw an imaginary line from Merak through Dubhe and project it outward approximately **5 times** the distance between them.
4. You will intercept **Polaris**, a moderately bright 2nd-magnitude star at the tip of the Little Dipper's handle (Ursa Minor).
5. Drop vertically from Polaris to the horizon: **that point on the horizon is True North**.