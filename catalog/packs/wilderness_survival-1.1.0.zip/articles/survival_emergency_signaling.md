# Emergency Visual Signaling & Ground-to-Air Codes

Search and rescue (SAR) fixed-wing aircraft and helicopters fly at high speeds; active and passive ground visual distress signals maximize visibility across vast topography.

## 1. Ground-to-Air Emergency Visual Code (ICAO Standard)
Construct symbols using high-contrast materials (shadowed logs, bright rocks, stamped snow trenches):
- **V : Require Assistance**
- **X : Require Medical Assistance**
- **N : No or Negative**
- **Y : Yes or Affirmative**
- **-> : Proceeding in this Direction**
*Dimensions:* Minimum 3 meters (10 feet) long, 1 meter wide, separated by 1 meter.

## 2. Signal Mirror Aiming (Flash Alignment Technique)
*A glass or metal signal mirror generates flashes visible up to 50 km (30 miles) under clear conditions.*
1. Hold the mirror in one hand close to your cheek, looking toward the target aircraft or boat.
2. Extend your opposite arm straight out toward the target with your fingers spread in a **"V" notch**, positioning the aircraft directly between your two fingertips.
3. Tilt the mirror until the reflected sunlight beam hits your hand.
4. Sweep the flash directly through the "V" notch across the target back and forth.

## 3. The International Rule of Three
- Three signals of any kind indicate life-threatening distress:
  - 3 fire plumes laid out in an equilateral triangle (30 meters apart).
  - 3 sharp blasts on a whistle.
  - 3 flashes of a mirror or flashlight in sequence, followed by a 1-minute pause.