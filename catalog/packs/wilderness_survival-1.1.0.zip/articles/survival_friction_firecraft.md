# Primitive Friction Firecraft & Ferrocerium Ignition

Fire fulfills multiple survival requirements: thermoregulation, water purification, signaling, pathogen reduction in food, and predator deterrence.

## 1. The Fire Triangle & Combustion Stages
- **Tinder:** Fluffy, micro-fibrous dry plant material that ignites from a tiny spark or glowing ember (inner dry cedar bark, cattail fluff, charred cotton cloth, dried bracket fungus).
- **Kindling:** Matchstick to thumb-thickness dry twigs that bridge heat from burning tinder to main logs.
- **Fuel:** Wrist to thigh-thick hardwood logs that provide long-lasting radiant heat.

## 2. The Bow Drill Mechanism (Primitive Friction Fire)
1. **Spindle:** Straight hardwood cylinder, 20 cm long, 2 cm diameter. Carve top to a dull pencil point (low friction); carve base to a blunt round tip (high friction).
2. **Hearth Board:** Flat, dry softwood board (cedar, basswood, willow, poplar), 2 cm thick.
3. **Socket/Handhold:** Hardwood block or stone with a grease-lubricated depression to press down on the spindle.
4. **Bow:** Curved branch with non-stretch paracord looped with slight slack.
5. **Operation:**
   - Burn a pilot depression into the hearth board.
   - Cut a **60° V-notch** from the board edge into the center of the depression.
   - Place a dry leaf or bark flake under the notch to collect hot carbon dust.
   - Stroke the bow steadily with long, rhythmic passes.
   - Once thick, pungent white/grey smoke billows, increase stroke speed for 15 seconds until dust reaches **400°C (750°F)**.
   - A glowing red ember coalesces in the dust pile.
   - Transfer the ember into the center of your prepared tinder bird's nest; blow gently with steady breaths until flames erupt.