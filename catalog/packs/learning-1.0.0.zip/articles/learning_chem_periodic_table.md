# Periodic Table Principles & Chemical Bonding

The periodic table organizes all known chemical elements in order of increasing atomic number (Z, the number of protons in the nucleus). Periodic recurrence of chemical properties arises from electron configurations in outer valence shells.

## 1. Table Structure & Periodic Trends
- **Periods (Horizontal Rows 1 to 7):** Indicate the principal quantum number (n) of the highest occupied electron shell.
- **Groups (Vertical Columns 1 to 18):** Elements within the same column have identical numbers of valence electrons, leading to similar bonding behaviors.
  - Group 1: Alkali Metals (Li, Na, K - highly reactive, oxidation state +1).
  - Group 2: Alkaline Earth Metals (Be, Mg, Ca - oxidation state +2).
  - Group 17: Halogens (F, Cl, Br, I - strong oxidizers, valence 7, oxidation state -1).
  - Group 18: Noble Gases (He, Ne, Ar - complete octet, exceptionally unreactive).

## 2. Fundamental Periodic Trends
- **Atomic Radius:** Decreases across a period (left to right) due to increasing nuclear charge pulling electrons inward; increases down a group due to additional electron shielding shells.
- **Electronegativity (Pauling Scale):** The tendency of an atom to attract shared electrons in a bond. Increases left-to-right (Fluorine has highest at 3.98) and decreases down a group.

## 3. Chemical Bonding Types
- **Ionic Bond:** Formed when the electronegativity difference between two atoms is large (Delta EN > 1.7). Complete transfer of one or more valence electrons forms cations and anions held by electrostatic attraction (e.g., Na+ + Cl- -> NaCl).
- **Covalent Bond:** Formed when atoms share electron pairs (Delta EN < 1.7).
  - Non-polar covalent: Equal sharing (O2, CH4).
  - Polar covalent: Unequal sharing producing partial charges (H2O).