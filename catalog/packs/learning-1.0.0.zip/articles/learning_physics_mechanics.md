# Classical Mechanics & Laws of Conservation

Classical mechanics describes the motion of macroscopic objects under the influence of forces. It is grounded in Sir Isaac Newton's three laws of motion and the conservation laws of energy and momentum.

## 1. Newton's Three Laws of Motion
1. **First Law (Law of Inertia):** An object at rest remains at rest, and an object in motion continues in motion with constant velocity along a straight line, unless acted upon by a net external force (sum F = 0 implies a = 0).
2. **Second Law (Fundamental Law of Dynamics):** The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass:
   F_net = m * a = dp/dt
   Units: Force in Newtons (N), where 1 N = 1 kg*m/s^2.
3. **Third Law (Action and Reaction):** For every action, there is an equal and opposite reaction:
   F_{A -> B} = -F_{B -> A}

## 2. Conservation of Mechanical Energy
In an isolated system subject only to conservative forces (such as gravity and ideal springs), total mechanical energy (E) remains constant over time:
E = E_k + E_p = constant
- **Kinetic Energy:** E_k = 0.5 * m * v^2
- **Gravitational Potential Energy:** E_p = m * g * h (where g approx 9.81 m/s^2)

## 3. Conservation of Linear Momentum
The total linear momentum (p = m * v) of a closed system without external impulses is strictly conserved:
sum m_i * v_{i,before} = sum m_i * v_{i,after}
- **Elastic Collision:** Both total kinetic energy and momentum are conserved (e = 1).
- **Inelastic Collision:** Momentum is conserved, but kinetic energy is partially converted into internal thermal energy or deformation (e < 1).