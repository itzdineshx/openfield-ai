# High-Reliability Wire Splicing & Weatherproofing (Lineman Splice)

Field-spliced conductor joints must withstand physical tensile strain, vibration, temperature cycling, and moisture ingress without degradation of electrical conductivity.

## 1. The Western Union (Lineman) Splice
*The NASA and military aviation benchmark for joining solid or stranded conductors subject to mechanical tension.*

1. **Stripping:** Strip 3 to 4 cm (1.2 to 1.5 inches) of insulation from both wire ends without nicking or cutting copper conductor strands.
2. **Crossed Alignment:** Cross the two exposed conductors at right angles, approximately one-third of the distance from the insulation jacket.
3. **Interlocking Twist:** Twist the wires together for 2 to 3 interlocking center turns.
4. **Wrapping:** Wrap the remaining ends tightly around the straight opposite conductor for at least **4 to 5 complete, tight, closed coils**.
5. **Trim & Crimp:** Snip wire tips flush so sharp ends do not puncture heat-shrink insulation.
6. **Soldering:** Apply rosin flux, heat the center of the splice with a soldering iron tip, and feed solder until it flows completely into the inter-strand gaps via capillary action.

## 2. Weatherproofing & Moisture Sealing Hierarchy
1. **Dual-Wall Adhesive-Lined Heat Shrink (Marine Grade):**
   - Slip tubing over conductor prior to splicing.
   - Standard single-wall heat shrink allows capillary moisture ingress along the wire strands.
   - Dual-wall tubing contains an inner liner of hot-melt thermoplastic adhesive that liquifies when heated (at 120°C) and forms an airtight, hermetic moisture barrier.
2. **Self-Amalgamating Silicone Tape:**
   - Non-adhesive silicone rubber that chemically bonds to itself when stretched by 200% and wrapped with 50% overlap.
   - Resistant to UV degradation, ozone, and temperatures up to 260°C.
3. **Dielectric Silicone Compound:**
   - Coat terminal spade and screw terminals with pure dielectric silicone grease to displace atmospheric moisture and prevent galvanic corrosion between dissimilar metals (e.g. copper wire under steel screw).