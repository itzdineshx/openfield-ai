# Field Oscilloscope Operation & Signal Integrity Diagnostics

A digital storage oscilloscope (DSO) converts transient electrical voltages into two-dimensional graphical time-domain displays ($V$ vs $t$), allowing isolation of noise glitches, clock jitter, and bus protocol corruptions.

## 1. Probe Attenuation (1X vs 10X Selection)
- **10X Mode (Standard Operational Setting):**
  - Inserts a 9 MΩ resistor in series with the oscilloscope's 1 MΩ input impedance, creating a 10:1 voltage divider.
  - Increases probe input impedance to **10 MΩ** and dramatically reduces input capacitance from ~100pF down to **10pF to 15pF**.
  - Reduces high-frequency circuit loading. Always use 10X for clock lines, SPI/I2C buses, and high-frequency digital signals.
- **1X Mode:**
  - Full signal amplitude; limited bandwidth (typically <10 MHz) and high capacitance (~100pF). Use only for ultra-low-voltage microvolt audio signals or small power rail ripple measurements.

## 2. Probe Low-Frequency Compensation (Square Wave Trimming)
Before making precision measurements, always calibrate passive probes using the oscilloscope's 1 kHz reference square wave test terminal:
- Connect probe tip and ground alligator clip to the calibrator loop.
- Use a non-conductive ceramic trimming screwdriver to adjust the trimmer capacitor on the probe BNC connector:
  - **Overcompensated:** Leading edge shows rounded overshoot spikes.
  - **Undercompensated:** Leading edge is sluggish and rolled off.
  - **Correctly Compensated:** Clean, flat horizontal tops with sharp 90° transitions.

## 3. Triggering Modes
- **Auto:** Sweeps display continuously even in the absence of a trigger event. Ideal for searching for baseline DC levels and unknown frequencies.
- **Normal:** Sweeps display **only** when input signal crosses the selected trigger voltage threshold with the chosen slope (Rising/Falling). Necessary for capturing non-periodic or bursty signals (e.g., UART packet bursts).
- **Single Shot:** Captures exactly one waveform acquisition when triggered and freezes memory buffer. Essential for recording power-on reset sequences, transient voltage spikes, and latch-up events.

## 4. Ground Lead Inductance & "Ground Bounce"
The standard 15 cm alligator ground lead has approximately 100 nH of parasitic inductance ($L_{lead}$). Fast digital transition edges ($di/dt$) induce voltage ringing:
$$V_{ring} = L_{lead} \cdot \frac{di}{dt}$$
- To observe true signal edges without synthetic ground ringing artifacts, remove the long alligator ground lead and clip on a short coaxial **ground spring contact** directly touching the ground pad adjacent to the signal test point.