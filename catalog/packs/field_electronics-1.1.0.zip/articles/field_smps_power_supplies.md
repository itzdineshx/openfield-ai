# Switched-Mode Power Supply (SMPS) Topologies & Fault Isolation

Switched-Mode Power Supplies provide DC-DC voltage conversion with high thermal efficiency (85% to 96%) using high-frequency pulse-width modulation (PWM), energy-storage inductors, and synchronous MOSFETs.

## 1. Core Conversion Topologies
- **Buck (Step-Down):** Produces lower output voltage ($V_{out} = D \cdot V_{in}$, where $D$ is duty cycle $0 < D < 1$).
  - High-side MOSFET switches input voltage; inductor and low-side synchronous FET (or freewheeling Schottky diode) filter current into output capacitor bank.
- **Boost (Step-Up):** Produces higher output voltage ($V_{out} = V_{in} / (1 - D)$).
  - Inductor stores magnetic energy during switch ON-time; discharges through diode into output capacitors during switch OFF-time.
- **Buck-Boost / SEPIC:** Inverts or regulates output voltage above or below input rail.

## 2. Systematic Troubleshooting Workflow
1. **Verify Input Voltage & Inrush Limiter:**
   - Check input fuse or reverse-polarity protection P-channel MOSFET.
   - Inspect input NTC thermistor (cold resistance typically 5Ω to 10Ω; drops to <0.5Ω when hot).
2. **Inspect the Switching Node (LX / SW Pad):**
   - In a functioning buck converter, the junction between the high-side FET, low-side FET, and inductor must toggle between 0V and $V_{in}$ at the switching frequency (typically 300 kHz to 2 MHz).
   - If SW node is pegged at 0V: High-side FET is open, controller has no VCC, or Enable pin is pulled low.
   - If SW node is shorted to $V_{in}$: High-side FET has suffered drain-source punch-through, sending raw unmitigated input voltage directly to downstream logic ICs!
3. **Feedback Resistor Divider ($R_{fb1}, R_{fb2}$):**
   - Output voltage is governed by internal bandgap reference $V_{ref}$ (typically 0.6V or 0.8V):
     $$V_{out} = V_{ref} \cdot \left(1 + \frac{R_1}{R_2}\right)$$
   - If output voltage drifts high: $R_2$ is open or has increased in resistance.
   - If output voltage is lower than nominal: $R_1$ has drifted high or feedback trace has leakage to ground.

## 3. Inductor Saturation & Capacitor Degradation
- **Inductor Saturation:** When inductor current exceeds saturation rating ($I_{sat}$), core permeability drops precipitously, turning the inductor into a plain copper wire loop. This causes instantaneous current spikes and destroys switching MOSFETs.
- **Electrolytic Output Capacitor Dry-Out:** High ripple currents boil liquid electrolyte over time, dramatically increasing Equivalent Series Resistance (ESR) and generating high output ripple voltage that resets sensitive microcontrollers.