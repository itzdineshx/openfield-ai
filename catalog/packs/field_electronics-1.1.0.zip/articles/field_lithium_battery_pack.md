# Lithium-Ion & LiFePO4 Battery Pack Diagnostics & BMS Restoration

Secondary lithium cells possess high specific energy density. Understanding chemistry voltage boundaries, cell balancing tolerances, and Battery Management System (BMS) trip states prevents catastrophic thermal runaway.

## 1. Chemical Specifications Comparison
| Parameter | Li-Ion (NMC / Cobalt 18650/21700) | LiFePO4 (Lithium Iron Phosphate) | Li-Po (Lithium Polymer Pouch) |
|---|---|---|---|
| **Nominal Voltage** | 3.6V - 3.7V per cell | 3.2V per cell | 3.7V per cell |
| **Max Charge Cutoff** | 4.20V ± 0.05V | 3.65V ± 0.05V | 4.20V (4.35V for LiHV) |
| **Storage Voltage** | 3.82V - 3.85V | 3.30V | 3.85V |
| **Min Discharge Cutoff**| 2.80V (Damage below 2.5V) | 2.50V (Damage below 2.0V) | 3.00V |
| **Thermal Runaway Temp**| ~150°C - 180°C | >270°C (Extremely stable) | ~140°C |

## 2. Diagnosing Cell Imbalance in Series Strings (e.g. 3S, 4S, 7S, 13S)
- Access the multi-pin white JST balance connector on the battery pack.
- Measure voltage of each individual cell sequentially between consecutive balance pins ($B_0-B_1, B_1-B_2, B_2-B_3$).
- **Tolerance Standards:**
  - Optimal Pack: Delta between highest and lowest cell is **<20mV (0.02V)**.
  - Mild Degradation: Delta between 20mV and 80mV. Charge capacity is throttled by the weakest cell.
  - Critical Fault: Delta **>150mV (0.15V)**. BMS will trigger premature low-voltage cutoff during discharge or overvoltage cutoff during charge.

## 3. BMS Lockout State & "Jumpstart" Procedure
When a single cell drops beneath the low-voltage cutoff threshold (typically 2.4V for Li-ion), the protection IC enters hard lockout mode, turning off both the charge and discharge MOSFET gates (reading 0.0V at the main P+ / P- output terminals).
1. Isolate the pack from loads and inspect cells physically. If any cell is bloated, dented, or below 1.5V, do not revive (internal copper dendrite short risk).
2. If cells are resting safely between 2.2V and 2.5V:
   - Connect a bench power supply set to nominal pack voltage with current limited to **50mA to 100mA** (trickle pre-charge rate).
   - Apply power for 30 to 60 seconds across P+ and P- to trigger the BMS threshold detector.
   - Once cell voltages rise above 2.8V, the BMS restores normal switching mode.

## 4. C-Rating and Safe Current Delivery
- Discharge Current formula: $I_{max} = C_{rating} \times Capacity_{Ah}$.
  - A 2500mAh (2.5Ah) cell rated at 10C can deliver $2.5 \times 10 = 25A$ continuous load.
  - Operating above manufacturer C-rating causes severe I²R resistive heating and accelerated SEI layer breakdown.