# Digital Multimeter Diagnostics & In-Circuit Component Testing

A high-input-impedance (>=10 MΩ) Digital Multimeter (DMM) allows diagnosis of passive and active components without loading low-power reference circuits.

## 1. Operating Modes & Measurement Procedures
- **DC Voltage (V⎓):** Measures potential difference. Connect black lead to common chassis ground (GND) and red lead to test points.
  - *Measurement Rule:* Logic signals (1.8V, 3.3V, 5V) should remain within ±3% tolerance under nominal load. A drooping rail (e.g. 3.3V rail measuring 2.7V) indicates excessive load or high series resistance in a ferrite bead.
- **Continuity (Beeper):** Alerts with a tone when circuit loop resistance is beneath approximately 30Ω to 50Ω.
  - *Field Caution:* Always perform continuity checks on unpowered systems. Residual DC charges trigger false buzzers or blow meter input fuses.
- **Resistance (Ω):** In-circuit measurements read the equivalent parallel resistance of all attached loop branches ($R_{eq} = (R_1 \cdot R_2) / (R_1 + R_2)$). To verify precision tolerance resistors, lift at least one pin from the solder pad.
- **Diode Mode (Forward Voltage Drop $V_f$):** Injects a calibrated 1mA current and measures forward junction barrier potential:
  - Standard Silicon PN Junction: `0.55V to 0.70V`.
  - Schottky Diode (Fast Barrier): `0.18V to 0.35V`.
  - Germanium Diode: `0.22V to 0.30V`.
  - Gallium Arsenide LED: Red (`1.6V - 2.0V`), Green/Blue/White (`2.8V - 3.4V`).
  - *Short:* `0.000V` in both directions indicates semiconductor breakdown.
  - *Open:* Displays `OL` (Over Limit) in both directions.

## 2. In-Circuit Ceramic Capacitor (MLCC) Short Testing
Multi-layer ceramic capacitors frequently fail as dead shorts due to microscopic thermal cracking or voltage spike breakdown:
1. De-energize circuit completely and discharge bulk capacitors through a 1 kΩ 5W power resistor.
2. In Resistance mode, measure between the power rail and ground.
3. If reading is <2Ω, a short exists. Because dozens of decoupling capacitors sit in parallel on a power bus, pinpoint the shorted capacitor using:
   - **Voltage Injection Method:** Inject 1.0V with current limited to 1.5A into the rail. Spray 99% Isopropyl Alcohol (IPA). The defective capacitor boils and evaporates the alcohol within seconds while healthy components stay wet.

## 3. Transistor Field Testing (BJT & MOSFET)
- **NPN Bipolar Junction Transistor (Diode Mode):**
  - Red probe on Base: Black probe on Collector reads `~0.65V`, Black probe on Emitter reads `~0.68V`.
  - Reverse probes: All combinations read `OL`.
- **N-Channel Enhancement MOSFET:**
  - Black probe on Source, Red probe on Drain reads `0.45V to 0.60V` (internal body diode). Reverse reads `OL`.
  - Touch Red probe momentarily to Gate (charges internal input capacitance $C_{iss}$).
  - Return Red probe to Drain: MOSFET now conducts; meter reads `0.00V` (Rds-on active).
  - Discharge Gate by touching Gate and Source together with fingers; Drain-to-Source returns to `OL`.